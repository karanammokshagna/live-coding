import { useEffect, useState } from "react";
import {
  FileSearch, LayoutDashboard, History, LogOut, UploadCloud, FileText,
  CheckCircle2, AlertCircle, Sparkles, Trash2, UserRound, ArrowRight,
  BrainCircuit, Target, Lightbulb, Menu, X
} from "lucide-react";
import api from "./api";

function App() {
  const [token, setToken] = useState(localStorage.getItem("token"));
  const [user, setUser] = useState(null);
  const [page, setPage] = useState("analyze");
  const [authMode, setAuthMode] = useState("login");
  const [auth, setAuth] = useState({ name: "", email: "", password: "" });
  const [file, setFile] = useState(null);
  const [jobDescription, setJobDescription] = useState("");
  const [targetRole, setTargetRole] = useState("");
  const [analysis, setAnalysis] = useState(null);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [mobileNav, setMobileNav] = useState(false);

  useEffect(() => {
    if (token) {
      api.get("/auth/me").then(r => setUser(r.data.user)).catch(() => logout());
    }
  }, [token]);

  useEffect(() => {
    if (token && page === "history") loadHistory();
  }, [token, page]);

  function logout() {
    localStorage.removeItem("token");
    setToken(null); setUser(null); setAnalysis(null); setHistory([]);
  }

  async function submitAuth(e) {
    e.preventDefault(); setLoading(true); setMessage("");
    try {
      const endpoint = authMode === "login" ? "/auth/login" : "/auth/register";
      const { data } = await api.post(endpoint, auth);
      localStorage.setItem("token", data.token);
      setToken(data.token); setUser(data.user); setPage("analyze");
    } catch (err) {
      setMessage(err.response?.data?.message || "Authentication failed");
    } finally { setLoading(false); }
  }

  async function analyze(e) {
    e.preventDefault();
    if (!file) return setMessage("Choose a resume file first.");
    if (!jobDescription.trim()) return setMessage("Paste the job description first.");
    const form = new FormData();
    form.append("resume", file);
    form.append("jobDescription", jobDescription);
    form.append("targetRole", targetRole);
    setLoading(true); setMessage(""); setAnalysis(null);
    try {
      const { data } = await api.post("/analysis", form, {
        headers: { "Content-Type": "multipart/form-data" }
      });
      setAnalysis(data.analysis);
      setMessage("Analysis completed successfully.");
    } catch (err) {
      setMessage(err.response?.data?.message || "Could not analyze resume.");
    } finally { setLoading(false); }
  }

  async function loadHistory() {
    try { const { data } = await api.get("/analysis/history"); setHistory(data.analyses); }
    catch { setMessage("Could not load history."); }
  }

  async function deleteAnalysis(id) {
    if (!window.confirm("Delete this analysis?")) return;
    try { await api.delete(`/analysis/${id}`); loadHistory(); }
    catch { setMessage("Could not delete analysis."); }
  }

  if (!token || !user) {
    return <div className="auth-shell">
      <div className="auth-visual">
        <div className="brand"><div className="brand-icon"><BrainCircuit size={22}/></div> ResumeIQ</div>
        <div className="auth-copy">
          <span className="eyebrow">CAREER TOOLKIT</span>
          <h1>Your next opportunity starts with a stronger resume.</h1>
          <p>Understand your resume match, discover missing skills and make your experience easier to find.</p>
          <div className="visual-card"><div className="visual-top"><span>Resume match</span><span className="live-dot">● LIVE ANALYSIS</span></div><div className="visual-score">86<span>/100</span></div><div className="progress"><i style={{width:"86%"}}/></div><div className="visual-foot"><span>✓ Skills identified</span><span>↗ Actionable tips</span></div></div>
        </div>
        <div className="auth-bottom">A clearer way to prepare for your next role.</div>
      </div>
      <div className="auth-panel">
        <form className="auth-form" onSubmit={submitAuth}>
          <div className="mobile-brand brand"><div className="brand-icon"><BrainCircuit size={22}/></div> ResumeIQ</div>
          <span className="eyebrow">{authMode === "login" ? "WELCOME BACK" : "GET STARTED"}</span>
          <h2>{authMode === "login" ? "Sign in to your account" : "Create your account"}</h2>
          <p className="muted">{authMode === "login" ? "Continue improving your resume." : "Create an account to save your analyses."}</p>
          {authMode === "register" && <label>Full name<input required value={auth.name} onChange={e=>setAuth({...auth,name:e.target.value})} placeholder="Your name"/></label>}
          <label>Email address<input required type="email" value={auth.email} onChange={e=>setAuth({...auth,email:e.target.value})} placeholder="you@example.com"/></label>
          <label>Password<input required minLength="8" type="password" value={auth.password} onChange={e=>setAuth({...auth,password:e.target.value})} placeholder="At least 8 characters"/></label>
          {message && <div className="notice error"><AlertCircle size={16}/>{message}</div>}
          <button className="primary full" disabled={loading}>{loading ? "Please wait..." : authMode === "login" ? "Sign in" : "Create account"} <ArrowRight size={17}/></button>
          <p className="switch-auth">{authMode === "login" ? "Don't have an account?" : "Already registered?"} <button type="button" onClick={()=>{setAuthMode(authMode==="login"?"register":"login");setMessage("");}}>{authMode==="login"?"Create account":"Sign in"}</button></p>
        </form>
      </div>
    </div>;
  }

  const nav = <><button className={page==="analyze"?"nav-item active":"nav-item"} onClick={()=>{setPage("analyze");setMobileNav(false);}}><FileSearch size={18}/> Analyze resume</button><button className={page==="history"?"nav-item active":"nav-item"} onClick={()=>{setPage("history");setMobileNav(false);}}><History size={18}/> Analysis history</button></>;

  return <div className="app-shell">
    <aside className={mobileNav?"sidebar open":"sidebar"}>
      <div className="brand"><div className="brand-icon"><BrainCircuit size={22}/></div> ResumeIQ</div>
      <div className="side-label">WORKSPACE</div>{nav}
      <div className="sidebar-bottom"><div className="profile"><div className="avatar">{user.name?.[0]?.toUpperCase()}</div><div className="profile-info"><b>{user.name}</b><span>{user.email}</span></div></div><button className="logout" onClick={logout}><LogOut size={17}/> Sign out</button></div>
    </aside>
    {mobileNav && <button className="scrim" onClick={()=>setMobileNav(false)} aria-label="Close menu"/>}
    <main className="main-area">
      <header className="topbar"><button className="mobile-menu" onClick={()=>setMobileNav(!mobileNav)}><Menu/></button><div><span className="top-kicker">WORKSPACE / {page==="analyze"?"ANALYZER":"HISTORY"}</span><h2>{page==="analyze"?"Resume analyzer":"Your analysis history"}</h2></div><div className="top-user"><div className="avatar small">{user.name?.[0]?.toUpperCase()}</div><span>{user.name}</span></div></header>
      <div className="content">
        {message && <div className={`notice ${message.includes("successfully")?"success":""}`}><CheckCircle2 size={16}/>{message}<button onClick={()=>setMessage("")}>×</button></div>}
        {page==="analyze" ? <>
          <div className="intro-row"><div><span className="eyebrow">SMART CAREER INSIGHTS</span><h1>Make your resume work harder.</h1><p className="muted">Compare your resume against a job description and get practical ways to improve.</p></div><div className="intro-icon"><Sparkles size={27}/></div></div>
          <form className="analyzer-grid" onSubmit={analyze}>
            <section className="panel form-panel">
              <div className="section-heading"><div className="step">01</div><div><h3>Upload your resume</h3><p>Start with your latest resume document.</p></div></div>
              <label className="upload-box">
                <input type="file" accept=".pdf,.docx,.txt" onChange={e=>setFile(e.target.files[0]||null)}/>
                <div className="upload-icon"><UploadCloud size={25}/></div>
                <b>{file ? file.name : "Click to upload or drag your file here"}</b>
                <span>{file ? `${(file.size/1024/1024).toFixed(2)} MB · Ready to analyze` : "PDF, DOCX or TXT · Maximum 5 MB"}</span>
              </label>
              <label className="field-label">Target job title <span className="optional">OPTIONAL</span><input value={targetRole} onChange={e=>setTargetRole(e.target.value)} placeholder="e.g. Junior React Developer"/></label>
              <div className="privacy-note"><CheckCircle2 size={16}/> Your uploaded file is processed in memory and is not saved.</div>
            </section>
            <section className="panel form-panel">
              <div className="section-heading"><div className="step">02</div><div><h3>Add job description</h3><p>Paste the role requirements you want to match.</p></div></div>
              <textarea className="job-input" required minLength="30" value={jobDescription} onChange={e=>setJobDescription(e.target.value)} placeholder={"Paste the job description here...\n\nExample:\nWe are looking for a React developer with JavaScript, HTML, CSS, Node.js and MongoDB experience..."} />
              <div className="char-count">{jobDescription.length} characters · Minimum 30</div>
              <button className="primary full analyze-btn" disabled={loading}>{loading ? <><span className="spinner"/> Analyzing your resume...</> : <><Sparkles size={17}/> Analyze resume</>}</button>
            </section>
          </form>
          {analysis && <Results analysis={analysis}/>}
          {!analysis && <div className="how-row"><div><Target size={19}/><span><b>Match score</b><small>See how closely your resume aligns</small></span></div><div><FileText size={19}/><span><b>Skill insights</b><small>Find strengths and missing skills</small></span></div><div><Lightbulb size={19}/><span><b>Improvement tips</b><small>Get practical next steps</small></span></div></div>}
        </> : <section className="panel history-panel"><div className="history-heading"><div><h3>Previous analyses</h3><p className="muted">Your latest 50 saved resume analyses.</p></div><button className="secondary" onClick={loadHistory}>Refresh</button></div>
          {history.length===0 ? <div className="empty"><History size={32}/><b>No analyses yet</b><span>Analyze your first resume to see it here.</span><button className="primary" onClick={()=>setPage("analyze")}>Analyze a resume</button></div> :
            <div className="history-list">{history.map(item=><div className="history-item" key={item._id}><div className="file-icon"><FileText/></div><div className="history-meta"><b>{item.targetRole || "Resume analysis"}</b><span>{item.filename} · {new Date(item.createdAt).toLocaleDateString()}</span></div><div className="history-score">{item.score}%</div><button className="icon-btn danger" onClick={()=>deleteAnalysis(item._id)} title="Delete"><Trash2 size={17}/></button></div>)}</div>}
        </section>}
        <footer>ResumeIQ · Built with React, Node.js & MongoDB <span>Analysis is advisory, not a hiring decision.</span></footer>
      </div>
    </main>
  </div>;
}

function Results({analysis}) {
  const score = analysis.score || 0;
  return <section className="results-section">
    <div className="results-title"><div><span className="eyebrow">YOUR RESULTS</span><h2>Resume analysis complete</h2><p className="muted">{analysis.summary}</p></div><span className="result-pill"><CheckCircle2 size={15}/> Saved to history</span></div>
    <div className="result-grid">
      <div className="panel score-panel"><span className="eyebrow">OVERALL MATCH SCORE</span><div className="score-ring" style={{"--score":`${score*3.6}deg`}}><div><strong>{score}</strong><span>/100</span></div></div><b>{score>=80?"Strong alignment":score>=60?"Good starting point":score>=40?"Room to improve":"Needs attention"}</b><p className="muted">Based on skill match and job-description keyword coverage.</p></div>
      <div className="panel metric-panel"><div className="metric"><div className="metric-icon green"><CheckCircle2/></div><div><strong>{analysis.matchedSkills.length}</strong><span>Matching skills</span></div></div><div className="metric"><div className="metric-icon orange"><AlertCircle/></div><div><strong>{analysis.missingSkills.length}</strong><span>Missing skills</span></div></div><div className="metric"><div className="metric-icon blue"><Target/></div><div><strong>{analysis.keywordCoverage}%</strong><span>Keyword coverage</span></div></div></div>
    </div>
    <div className="result-grid skills-grid">
      <div className="panel skill-panel"><h3><CheckCircle2 className="green-text"/> Matching skills</h3><p className="muted">Skills found in both your resume and the job description.</p><div className="chips">{analysis.matchedSkills.length?analysis.matchedSkills.map(s=><span className="chip matched" key={s}>{s}</span>):<span className="muted">No matching skills identified.</span>}</div></div>
      <div className="panel skill-panel"><h3><AlertCircle className="orange-text"/> Skills to consider</h3><p className="muted">Skills found in the job description but not detected in your resume.</p><div className="chips">{analysis.missingSkills.length?analysis.missingSkills.map(s=><span className="chip missing" key={s}>{s}</span>):<span className="muted">No missing skills identified.</span>}</div></div>
    </div>
    <div className="panel tips-panel"><h3><Lightbulb className="tip-icon"/> Recommended improvements</h3><div className="tips-list">{analysis.suggestions.map((tip,i)=><div className="tip" key={i}><span>{String(i+1).padStart(2,"0")}</span>{tip}</div>)}</div></div>
  </section>;
}

export default App;
