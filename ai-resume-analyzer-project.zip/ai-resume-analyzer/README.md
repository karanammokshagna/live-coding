# AI Resume Analyzer (MERN Stack)

An intermediate-level full-stack academic project. Users register, log in, upload a PDF/DOCX/TXT resume, paste a job description, receive an ATS-style keyword/skills match score and suggestions, and view saved analysis history.

> The analyzer uses a transparent rule-based NLP-inspired scoring engine. It does not call a paid LLM API and is not a certified ATS or hiring decision tool.

## Features
- JWT authentication with bcrypt password hashing
- Resume upload: PDF, DOCX, TXT (maximum 5 MB)
- Job description comparison
- Skill extraction, matched/missing skills, keyword coverage
- Weighted match score and actionable suggestions
- MongoDB analysis history; full resume text is not stored
- Responsive React dashboard

## Requirements
- Node.js 18+
- MongoDB local installation or MongoDB Atlas
- npm

## 1. Backend setup
```bash
cd backend
cp .env.example .env
```
Edit `.env` and set `MONGO_URI` and a long random `JWT_SECRET`.

```bash
npm install
npm run dev
```
Backend runs at `http://localhost:5000`.

## 2. Frontend setup
Open another terminal:
```bash
cd frontend
npm install
npm run dev
```
Open the Vite URL printed in the terminal (usually `http://localhost:5173`).

## 3. First use
1. Register a new account.
2. Log in.
3. Upload your resume.
4. Paste the job description.
5. Click **Analyze Resume**.
6. Review the score, skills, missing keywords and suggestions.
7. Open **History** to view saved analyses.

## API routes
All routes are prefixed with `/api`.

| Method | Route | Auth | Purpose |
|---|---|---:|---|
| POST | `/auth/register` | No | Create account |
| POST | `/auth/login` | No | Login |
| GET | `/auth/me` | Yes | Current user |
| POST | `/analysis` | Yes | Upload and analyze resume |
| GET | `/analysis/history` | Yes | List own analyses |
| GET | `/analysis/:id` | Yes | Get one saved analysis |
| DELETE | `/analysis/:id` | Yes | Delete own analysis |

## Scoring method
- Skill match: 70% of score
- Job-description keyword coverage: 30% of score
- Skills are detected from a curated dictionary; keyword coverage uses normalized meaningful terms.
- Results are suggestions only. A human should review the resume and job requirements.

## Database collections
- `users`: name, email, password hash
- `analyses`: owner, filename, role, score, matched skills, missing skills, keyword coverage, suggestions, created date

The uploaded document is processed in memory and is not saved to disk or stored in MongoDB. Only analysis results are stored.

## Troubleshooting
- MongoDB connection error: ensure MongoDB is running and `MONGO_URI` is correct.
- CORS/network error: run frontend on Vite's default port and backend on port 5000.
- Invalid token: log out and log in again.
- PDF extraction issues: try a text-based PDF; scanned image-only PDFs require OCR, which is not included.
- Upload rejected: use PDF, DOCX or TXT and keep it below 5 MB.
