import mongoose from "mongoose";

const analysisSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  filename: { type: String, required: true },
  targetRole: { type: String, default: "Not specified" },
  score: { type: Number, required: true, min: 0, max: 100 },
  matchedSkills: [String],
  missingSkills: [String],
  keywordCoverage: { type: Number, min: 0, max: 100 },
  suggestions: [String],
  summary: { type: String, maxlength: 500 }
}, { timestamps: true });

export default mongoose.model("Analysis", analysisSchema);
