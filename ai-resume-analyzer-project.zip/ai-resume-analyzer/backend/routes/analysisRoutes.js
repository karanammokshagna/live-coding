import express from "express";
import multer from "multer";
import pdf from "pdf-parse";
import mammoth from "mammoth";
import Analysis from "../models/Analysis.js";
import { protect } from "../middleware/auth.js";
import { analyzeResume } from "../utils/analyzer.js";

const router = express.Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = [".pdf", ".docx", ".txt"];
    const ext = file.originalname.toLowerCase().slice(file.originalname.lastIndexOf("."));
    if (allowed.includes(ext)) cb(null, true);
    else cb(new Error("Only PDF, DOCX and TXT files are supported"));
  }
});

async function extractText(file) {
  const name = file.originalname.toLowerCase();
  if (name.endsWith(".pdf")) {
    const data = await pdf(file.buffer);
    return data.text;
  }
  if (name.endsWith(".docx")) {
    const result = await mammoth.extractRawText({ buffer: file.buffer });
    return result.value;
  }
  return file.buffer.toString("utf8");
}

router.post("/", protect, upload.single("resume"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ message: "Please upload a resume file" });
    const jobDescription = req.body.jobDescription?.trim();
    if (!jobDescription || jobDescription.length < 30) {
      return res.status(400).json({ message: "Please enter a job description of at least 30 characters" });
    }

    const resumeText = (await extractText(req.file)).replace(/\s+/g, " ").trim();
    if (resumeText.length < 40) {
      return res.status(400).json({ message: "Could not extract enough text. Try a text-based PDF or DOCX file." });
    }

    const result = analyzeResume(resumeText, jobDescription);
    const analysis = await Analysis.create({
      user: req.userId,
      filename: req.file.originalname,
      targetRole: (req.body.targetRole || "Not specified").slice(0, 100),
      ...result
    });
    res.status(201).json({ analysis });
  } catch (error) {
    res.status(500).json({ message: error.message || "Resume analysis failed" });
  }
});

router.get("/history", protect, async (req, res) => {
  const analyses = await Analysis.find({ user: req.userId })
    .select("-__v").sort({ createdAt: -1 }).limit(50);
  res.json({ analyses });
});

router.get("/:id", protect, async (req, res) => {
  const analysis = await Analysis.findOne({ _id: req.params.id, user: req.userId });
  if (!analysis) return res.status(404).json({ message: "Analysis not found" });
  res.json({ analysis });
});

router.delete("/:id", protect, async (req, res) => {
  const deleted = await Analysis.findOneAndDelete({ _id: req.params.id, user: req.userId });
  if (!deleted) return res.status(404).json({ message: "Analysis not found" });
  res.json({ message: "Analysis deleted" });
});

export default router;
