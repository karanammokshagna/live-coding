const SKILLS = [
  "javascript", "typescript", "python", "java", "c++", "c#", "react", "angular",
  "vue", "node.js", "express", "mongodb", "mysql", "postgresql", "html", "css",
  "tailwind", "bootstrap", "git", "github", "docker", "kubernetes", "aws", "azure",
  "linux", "rest api", "graphql", "machine learning", "deep learning", "data analysis",
  "pandas", "numpy", "scikit-learn", "tensorflow", "pytorch", "sql", "excel",
  "power bi", "tableau", "communication", "teamwork", "leadership", "problem solving",
  "agile", "figma", "ui/ux", "testing", "jest", "cypress", "spring boot", "django",
  "flask", "php", "redis", "firebase"
];

const STOP_WORDS = new Set([
  "the","and","for","with","you","your","are","our","this","that","from","will",
  "have","has","was","were","who","what","when","where","how","all","any","can",
  "not","but","into","their","they","them","his","her","its","job","role","work",
  "years","year","using","use","ability","strong","good","well","required","preferred",
  "candidate","responsibilities","requirements","experience","skills","knowledge"
]);

const escapeRegex = (value) => value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

export function analyzeResume(resumeText, jobText) {
  const resume = resumeText.toLowerCase();
  const job = jobText.toLowerCase();

  const requiredSkills = SKILLS.filter(skill =>
    new RegExp(`(^|[^a-z0-9+#])${escapeRegex(skill)}([^a-z0-9+#]|$)`, "i").test(job)
  );
  const detectedSkills = SKILLS.filter(skill =>
    new RegExp(`(^|[^a-z0-9+#])${escapeRegex(skill)}([^a-z0-9+#]|$)`, "i").test(resume)
  );

  const matchedSkills = requiredSkills.filter(skill => detectedSkills.includes(skill));
  const missingSkills = requiredSkills.filter(skill => !detectedSkills.includes(skill));

  const tokenize = (text) => [...new Set(
    text.toLowerCase().match(/[a-z][a-z0-9+#.-]{2,}/g) || []
  )].filter(word => !STOP_WORDS.has(word));

  const jobTerms = tokenize(job);
  const resumeTerms = new Set(tokenize(resume));
  const matchedTerms = jobTerms.filter(term => resumeTerms.has(term));
  const keywordCoverage = jobTerms.length
    ? Math.round((matchedTerms.length / jobTerms.length) * 100) : 0;

  const skillScore = requiredSkills.length
    ? (matchedSkills.length / requiredSkills.length) * 70
    : Math.min(detectedSkills.length * 7, 70);
  const score = Math.max(0, Math.min(100, Math.round(skillScore + keywordCoverage * 0.30)));

  const suggestions = [];
  if (missingSkills.length) {
    suggestions.push(`If you genuinely have them, add evidence for these missing skills: ${missingSkills.slice(0, 8).join(", ")}.`);
  }
  if (keywordCoverage < 50) {
    suggestions.push("Use relevant wording from the job description where it accurately describes your experience.");
  }
  if (!/education|degree|university|college/i.test(resume)) {
    suggestions.push("Add an Education section with your degree, institution and graduation year.");
  }
  if (!/project|built|developed|implemented/i.test(resume)) {
    suggestions.push("Include 2–3 projects and explain your contribution, tools and measurable outcomes.");
  }
  if (!/\b\d+%|\b\d+\s*(users|customers|projects|hours|days)\b/i.test(resume)) {
    suggestions.push("Where possible, quantify achievements with honest numbers, percentages or outcomes.");
  }
  if (!/experience|internship/i.test(resume)) {
    suggestions.push("Add internship, volunteering, freelance or practical project experience if applicable.");
  }
  if (!suggestions.length) {
    suggestions.push("Good coverage. Review formatting, spelling and whether every listed skill is supported by evidence.");
  }

  return {
    score,
    matchedSkills,
    missingSkills,
    keywordCoverage,
    suggestions,
    summary: `Matched ${matchedSkills.length} of ${requiredSkills.length} skills identified in the job description.`
  };
}
